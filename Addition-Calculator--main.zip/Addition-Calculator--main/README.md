Hey everyone this side rudransh goswami

In this project, I've build a very basic CLI airthmatic calculator. 

Which only performs additional calculations Sums:


I'be hoping u like this one, cause in this i've also used a very nice flow control.\


Created by:
Rudransh Goswami 

