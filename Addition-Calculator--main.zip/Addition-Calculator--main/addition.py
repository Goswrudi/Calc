# Building 

# 1st Using functions 
 
user = input('Enter your name sir/mam : ')


def addition(): 
    va1 = int(input('Enter 1st number : '))
    va2 = int(input('Enter 2nd number : '))
    solution = va1 + va2
    print(f'The solution of {va1}+{va2} is {solution}')

addition()  

user_request = str(input(f'Do you want to continue with more calculations : (y or n)'))

if(user_request == 'y'):
    addition()

elif(user_request ==  'n'):
    confirm = input(('Are u sure u don`t want to continue with more calculations? (y or n)'))

    if(confirm == 'y'):
        addition()
    
    elif(confirm == 'n'):
        print(f'OKay!!{user} no problem buddy!! ')

else:
    print(f'Invaild choice {user}!! Goodbye :( ')


