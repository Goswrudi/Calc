Name = str(input("What's you're name? : "))
choice1 = int(input("How many subjects do u have ? :)  "))

def avg():
    sub1 = int(input("Enter you marks of sub1 : "))
    sub2 = int(input("Enter you marks of sub2 : "))
    sub3 = int(input("Enter you marks of sub3 : "))
    avg = (sub1 + sub2 + sub3) / 3
    return avg

def avg1():
    sub1 = float(input("Enter you marks of sub1 : "))
    sub2 = float(input("Enter you marks of sub1 : "))
    sub3 = float(input("Enter you marks of sub1 : "))
    sub4 = float(input("Enter you marks of sub1 : "))
    sub5 = float(input("Enter you marks of sub1 : "))
    avg1 = (sub1 + sub2 + sub3 +sub4 + sub5) / 5
    return avg1

def avg2():
    sub1 = float(input("Enter you marks of sub1 : "))
    sub2 = float(input("Enter you marks of sub2 : "))
    sub3 = float(input("Enter you marks of sub3 : "))
    sub4 = float(input("Enter you marks of sub4 : "))
    sub5 = float(input("Enter you marks of sub5 : "))
    sub6 = float(input("Enter your marks o sub6 : "))
    avg2 = (sub1 + sub2 + sub3 + sub4 + sub5 + sub6) / 6
    return avg2

if(choice1 == 5):
    result = avg1()
    print(f"Sure {Name}, here is your percantage of this semester :, {result}% ")

elif(choice1 == 3):
    result = avg()
    print(f"Sure {Name}, here is your percantage of this semester :, {result}% ")

elif(choice1 == 6):
    result = avg2()
    print(f"Sure {Name}, here is your percantage of this semester :, {result}% ")

else:
    print("Something went wrong!! This system only supports subject number 3, 5, 6 :) for changes contact devloper from Readme.md :)  ")

 