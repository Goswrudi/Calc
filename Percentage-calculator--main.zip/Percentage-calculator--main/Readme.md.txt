Hey everyone this side rudransh goswami! aka programmer.......

Today i have built the Simple percntage using python 

# Simple Percentage Calculator (Python)

An adaptive, interactive CLI-based Percentage Calculator built with Python. This application allows users to dynamically calculate their academic semester percentages based on the number of subjects they are taking.

Features
- **Dynamic Subject Routing:** Supports distinct logic flows for 3, 5, or 6 subjects.
- **Functional Programming Architecture:** Built using modular functions (`avg()`, `avg1()`, `avg2()`) that leverage Python's `return` statement for clean data passing.
- **Precision Floating Points:** Accepts decimal inputs (`float`) to ensure highly accurate percentage computations.

Tech Stack & Concepts Used
- **Language:** Python 3
- **Concepts Applied:**
  - Conditional Logic Flow (`if`, `elif`, `else`)
  - User-defined Functions with encapsulation
  - Data Type Casting (`int` and `float`)
  - String Formatting (`f-strings`)

How to Run (Windows Setup)

1. Clone this repository using Git Bash or PowerShell:
   ```powershell
   git clone [your-repository-link]


-rudransh goswami