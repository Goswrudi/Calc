# Building a division calculator 


user_name = input('Hey! Welcome to my code, Enter your name please. : ')

var1 = int(input('Enter 1st number for divison : '))
var2 = int(input('Enter 1st number for divison : '))

def division():
    solution = var1 / var2
    print(f'The solution of {var1} / {var2} is {solution} : ')

division()

ask = input('Do u want to continue with more calculations? y or n : ')

if(ask == 'y'):
    division()

elif(ask == 'n'):
    ask_again = input('Are you sure?, y or n')

    if(ask_again == 'y'):
        print(f'Okay {user_name} : ')
    
    elif(ask_again == 'n'):
        division()

    else:
        print(f'Invalid choice choosen by the {user_name}')

