Hey everyone this side rudransh goswami...

I've built a divison calculator for 2 sums (using python)
and it is working... :) 


Created by :
Rudransh Goswami 

