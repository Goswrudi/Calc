# Building the final multipication calculator 

user_name = input('Enter your name : ')

def multiplication():
    var1 = int(input('Enter 1st digit for multiplication : '))
    var2 = int(input('Enter 2nd digit for multiplication : '))
    solution = var1 * var2
    print(f'The Solutiion of {var1} ** {var2} is {solution} :')

multiplication()

ask = input('Do u want to continue with more calculations? y or n : ')

if(ask == 'y'):
    multiplication()

elif(ask == 'n'):
    ask_again = input('Are you sure?, y or n : ')

    if(ask_again == 'y'):
        print(f'Okay {user_name} : ')
    
    elif(ask_again == 'n'):
        multiplication()

    else:
        print(f'Invalid choice choosen by the {user_name}')
