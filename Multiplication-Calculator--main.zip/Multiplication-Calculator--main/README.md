
Hey everyone this side rudrasnh goswsami 

In this program I've build a Cli based multiplication calculator 
and it only has 2 digit suims going to make this far!! .

and eventually it is working fine with a very structred flow control system...


Created by:
Rudransh Goswami 
